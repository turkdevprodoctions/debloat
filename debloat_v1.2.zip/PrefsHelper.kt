package com.centerteam.shell

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration

class PrefsHelper(context: Context) {
    private val p: SharedPreferences =
        context.getSharedPreferences("debloat", Context.MODE_PRIVATE)
    private val ctx: Context = context.applicationContext

    // === TEMA ===
    // "dark" | "light" | "auto"
    var theme: String
        get() = p.getString("theme", "auto") ?: "auto"
        set(v) = p.edit().putString("theme", v).apply()

    fun isDark(): Boolean {
        return when (theme) {
            "light" -> false
            "dark" -> true
            "auto" -> {
                val mode = ctx.resources.configuration.uiMode and
                        Configuration.UI_MODE_NIGHT_MASK
                mode == Configuration.UI_MODE_NIGHT_YES
            }
            else -> true
        }
    }

    // === FAVORİLER ===
    fun getFavorites(): Set<String> =
        p.getStringSet("favorites", emptySet()) ?: emptySet()

    fun setFavorites(set: Set<String>) {
        p.edit().putStringSet("favorites", set).apply()
    }

    fun isFavorite(pkg: String): Boolean = getFavorites().contains(pkg)

    fun toggleFavorite(pkg: String) {
        val favs = getFavorites().toMutableSet()
        if (favs.contains(pkg)) favs.remove(pkg) else favs.add(pkg)
        setFavorites(favs)
    }

    // === İSTATİSTİK ===
    var totalRemoved: Int
        get() = p.getInt("total_removed", 0)
        set(v) = p.edit().putInt("total_removed", v).apply()

    var totalFrozen: Int
        get() = p.getInt("total_frozen", 0)
        set(v) = p.edit().putInt("total_frozen", v).apply()

    // === ANİMASYON ===
    var animationsOn: Boolean
        get() = p.getBoolean("animations", true)
        set(v) = p.edit().putBoolean("animations", v).apply()

    // === SHIZUKU SETUP TAMAMLANDI MI? ===
    var setupCompleted: Boolean
        get() = p.getBoolean("setup_done", false)
        set(v) = p.edit().putBoolean("setup_done", v).apply()

    // === SON SEÇİLEN FİLTRE ===
    var lastFilter: String
        get() = p.getString("last_filter", "all") ?: "all"
        set(v) = p.edit().putString("last_filter", v).apply()
}