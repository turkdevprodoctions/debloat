package com.centerteam.shell

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuHelper {

    const val PERMISSION_REQUEST_CODE = 1001

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Exception) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(PERMISSION_REQUEST_CODE) } catch (_: Exception) {}
    }

    // ============================================
    // KOMUT ÇALIŞTIRMA (düzeltildi)
    // ============================================
    fun exec(cmd: Array<String>): String {
        return try {
            val cls = Class.forName("rikka.shizuku.Shizuku")
            val m = cls.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val proc = m.invoke(null, cmd, null, null) as Process

            // Çıktıyı oku
            val stdout = StringBuilder()
            val stderr = StringBuilder()

            val t1 = Thread {
                try {
                    proc.inputStream.bufferedReader().use { r ->
                        var line: String?
                        while (r.readLine().also { line = it } != null) {
                            stdout.append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }
            val t2 = Thread {
                try {
                    proc.errorStream.bufferedReader().use { r ->
                        var line: String?
                        while (r.readLine().also { line = it } != null) {
                            stderr.append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }

            t1.start(); t2.start()
            proc.waitFor()
            t1.join(1000); t2.join(1000)

            (stdout.toString() + "\n" + stderr.toString()).trim()
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    // ============================================
    // ⚡ HER UYGULAMAYI SİL (force)
    // 5 katmanlı deneme
    // ============================================
    fun forceRemove(pkg: String): Pair<String, String> {
        // 1. force uninstall
        val u1 = exec(arrayOf("pm", "uninstall", "--user", "0", "--force", pkg))
        if (u1.contains("Success", true)) return Pair("uninstalled", "✓ Silindi")

        // 2. normal uninstall
        val u2 = exec(arrayOf("pm", "uninstall", "--user", "0", pkg))
        if (u2.contains("Success", true)) return Pair("uninstalled", "✓ Silindi")

        // 3. disable + hide
        exec(arrayOf("pm", "disable-user", "--user", "0", pkg))
        exec(arrayOf("pm", "hide", "--user", "0", pkg))
        exec(arrayOf("pm", "suspend", "--user", "0", pkg))

        // doğrulama
        val check = exec(arrayOf("pm", "list", "packages", "-u"))
        val stillThere = check.lines().any { it.contains(pkg) }

        if (!stillThere) return Pair("hidden", "✓ Gizlendi ve devre dışı")

        // 4. Sadece disable
        val d = exec(arrayOf("pm", "disable-user", "--user", "0", pkg))
        if (!d.contains("Error", true) && !d.contains("ERROR")) {
            return Pair("disabled", "⚠ Donduruldu (silinemedi)")
        }

        // 5. Son çare: suspend
        val s = exec(arrayOf("pm", "suspend", "--user", "0", pkg))
        if (!s.contains("Error", true) && !s.contains("ERROR")) {
            return Pair("suspended", "⚠ Askıya alındı")
        }

        return Pair("failed", "✗ Başarısız - KNOX korumalı olabilir")
    }

    // ============================================
    // ❄️ DONDURMA (5 katmanlı)
    // ============================================
    fun freeze(pkg: String): Pair<String, String> {
        // 1. disable-user
        exec(arrayOf("pm", "disable-user", "--user", "0", pkg))
        if (isFrozen(pkg)) return Pair("disabled", "✓ Donduruldu")

        // 2. suspend (Android 12+)
        exec(arrayOf("pm", "suspend", "--user", "0", pkg))
        if (isFrozen(pkg)) return Pair("suspended", "✓ Askıya alındı")

        // 3. hide
        exec(arrayOf("pm", "hide", "--user", "0", pkg))
        if (isFrozen(pkg)) return Pair("hidden", "✓ Gizlendi")

        return Pair("failed", "✗ Dondurulamadı")
    }

    fun unfreeze(pkg: String): Boolean {
        exec(arrayOf("pm", "enable", pkg))
        exec(arrayOf("pm", "unhide", "--user", "0", pkg))
        exec(arrayOf("pm", "unsuspend", "--user", "0", pkg))
        return !isFrozen(pkg)
    }

    fun isFrozen(pkg: String): Boolean {
        return try {
            val out = exec(arrayOf("pm", "list", "packages", "-d", "-u"))
            out.lines().any { it.contains(pkg) }
        } catch (e: Exception) { false }
    }

    // ============================================
    // DİĞER İŞLEMLER
    // ============================================
    fun forceStop(pkg: String): Boolean {
        val out = exec(arrayOf("am", "force-stop", pkg))
        return !out.contains("Error", true) && !out.contains("ERROR")
    }

    fun clearData(pkg: String): Boolean {
        val out = exec(arrayOf("pm", "clear", pkg))
        return out.contains("Success", true)
    }

    fun launchApp(pkg: String): Boolean {
        // 1. monkey
        val monkey = exec(arrayOf("monkey", "-p", pkg,
            "-c", "android.intent.category.LAUNCHER", "1"))
        if (monkey.contains("Events injected")) return true

        // 2. am start
        val dumpsys = exec(arrayOf("dumpsys", "package", pkg))
        val regex = Regex("$pkg/([a-zA-Z0-9_.]+Activity)")
        val match = regex.find(dumpsys)?.groupValues?.get(1)
        if (match != null) {
            val result = exec(arrayOf("am", "start", "-n", "$pkg/$match"))
            return !result.contains("Error", true)
        }
        return false
    }

    fun getAllActivities(pkg: String): List<String> {
        return try {
            val dumpsys = exec(arrayOf("dumpsys", "package", pkg))
            val regex = Regex("$pkg/([a-zA-Z0-9_.]+)")
            regex.findAll(dumpsys).map { it.value }.toList().distinct()
        } catch (e: Exception) { emptyList() }
    }

    fun launchActivity(component: String): Boolean {
        val result = exec(arrayOf("am", "start", "-n", component))
        return !result.contains("Error", true)
    }

    // ============================================
    // DETAYLI UYGULAMA BİLGİSİ
    // ============================================
    fun getAppDetail(pkg: String): AppDetail {
        val dumpsys = exec(arrayOf("dumpsys", "package", pkg))

        val versionName = Regex("versionName=([^\\s]+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val versionCode = Regex("versionCode=(\\d+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val targetSdk = Regex("targetSdk=(\\d+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val minSdk = Regex("minSdk=(\\d+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val dataDir = Regex("dataDir=([^\\s]+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val codePath = Regex("codePath=([^\\s]+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val firstInstall = Regex("firstInstallTime=([^\\s]+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"
        val lastUpdate = Regex("lastUpdateTime=([^\\s]+)").find(dumpsys)
            ?.groupValues?.get(1) ?: "?"

        val permissions = Regex("android\\.permission\\.[A-Z_]+")
            .findAll(dumpsys).map { it.value }.distinct().toList()

        return AppDetail(
            versionName, versionCode, targetSdk, minSdk,
            dataDir, codePath, firstInstall, lastUpdate,
            permissions
        )
    }

    // ============================================
    // UYGULAMA BOYUTU
    // ============================================
    fun getAppSize(pkg: String): String {
        return try {
            val out = exec(arrayOf("du", "-sh", "/data/app/$pkg"))
            val parts = out.split("\\s+".toRegex())
            parts.firstOrNull { it.isNotEmpty() && it != "/data/app/$pkg" } ?: "?"
        } catch (e: Exception) { "?" }
    }
}

data class AppDetail(
    val versionName: String,
    val versionCode: String,
    val targetSdk: String,
    val minSdk: String,
    val dataDir: String,
    val codePath: String,
    val firstInstall: String,
    val lastUpdate: String,
    val permissions: List<String>
)