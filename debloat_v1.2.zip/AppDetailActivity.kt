package com.centerteam.shell

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.view.animation.TranslateAnimation
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class AppDetailActivity : Activity() {

    private lateinit var pkg: String
    private lateinit var prefs: PrefsHelper
    private var isSystemApp = false
    private var appName = ""
    private var appIcon: android.graphics.drawable.Drawable? = null
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        pkg = intent.getStringExtra("package") ?: run { finish(); return }

        try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            appName = packageManager.getApplicationLabel(info).toString()
            appIcon = packageManager.getApplicationIcon(info)
            isSystemApp = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
        } catch (e: Exception) {
            appName = pkg.substringAfterLast(".")
        }

        buildUI()
    }

    private fun buildUI() {
        val dark = prefs.isDark()
        val bg = if (dark) "#0B1120" else "#F8FAFC"
        val bg2 = if (dark) "#1E1B4B" else "#EEF2FF"
        val cardBg = if (dark) "#1E293B" else "#FFFFFF"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"
        val borderColor = if (dark) "#334155" else "#E2E8F0"

        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(bg), Color.parseColor(bg2))
            )
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 80, 24, 80)
        }
        scroll.addView(root)

        // === GERİ BUTONU ===
        val backRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }
        backRow.addView(TextView(this).apply {
            text = "← Geri"
            textSize = 15f
            setTextColor(Color.parseColor("#8B5CF6"))
            setPadding(15, 10, 15, 10)
            isClickable = true
            setOnClickListener { finish() }
        })
        backRow.addView(TextView(this).apply {
            text = " "
            layoutParams = LinearLayout.LayoutParams(0, 1, 1f)
        })
        backRow.addView(TextView(this).apply {
            text = if (prefs.isFavorite(pkg)) "⭐" else "☆"
            textSize = 22f
            setPadding(15, 10, 15, 10)
            isClickable = true
            setOnClickListener {
                prefs.toggleFavorite(pkg)
                toast(if (prefs.isFavorite(pkg)) "⭐ Favorilere eklendi" else "Favoriden çıkarıldı")
                buildUI()
            }
        })
        root.addView(backRow)

        // === HEADER ===
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }
        header.addView(ImageView(this).apply {
            setImageDrawable(appIcon)
            layoutParams = LinearLayout.LayoutParams(140, 140).apply {
                setMargins(0, 0, 25, 0)
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
        })
        val headerTexts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerTexts.addView(TextView(this).apply {
            text = appName
            textSize = 24f
            setTextColor(Color.parseColor(textColor))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        headerTexts.addView(TextView(this).apply {
            text = pkg
            textSize = 12f
            setTextColor(Color.parseColor(mutedColor))
            setPadding(0, 6, 0, 0)
        })
        header.addView(headerTexts)
        root.addView(header)

        // === TÜR ===
        val typeBadge = if (isSystemApp) "⚙️ SİSTEM UYGULAMASI" else "📱 KULLANICI UYGULAMASI"
        val typeColor = if (isSystemApp) "#F59E0B" else "#10B981"
        root.addView(TextView(this).apply {
            text = typeBadge
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(20, 15, 20, 15)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(typeColor))
                cornerRadius = 20f
            }
        })

        // === RİSK KARTI ===
        val risk = CriticalApps.check(pkg)
        val riskColor = when (risk.level) {
            "critical" -> "#DC2626"
            "warning" -> "#F59E0B"
            "safe" -> "#10B981"
            else -> "#64748B"
        }
        val riskCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 25, 30, 25)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(riskColor))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 20, 0, 20) }
        }
        riskCard.addView(TextView(this).apply {
            text = risk.message
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        riskCard.addView(TextView(this).apply {
            text = risk.reason
            textSize = 12f
            setTextColor(Color.parseColor("#F0F0F0"))
            setPadding(0, 10, 0, 0)
            setLineSpacing(4f, 1.3f)
        })
        root.addView(riskCard)

        // === DETAYLI BİLGİ ===
        root.addView(section("📊 UYGULAMA BİLGİSİ", mutedColor))

        val detail = try { ShizukuHelper.getAppDetail(pkg) } catch (e: Exception) { null }
        detail?.let {
            root.addView(infoRow("Sürüm", it.versionName, cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("Version Code", it.versionCode, cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("Hedef SDK", it.targetSdk, cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("Min SDK", it.minSdk, cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("İzin Sayısı", it.permissions.size.toString(), cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("Kurulum", it.firstInstall.take(19), cardBg, textColor, mutedColor, borderColor))
            root.addView(infoRow("Güncelleme", it.lastUpdate.take(19), cardBg, textColor, mutedColor, borderColor))

            // Boyut
            val sizeStr = try { ShizukuHelper.getAppSize(pkg) } catch (e: Exception) { "?" }
            root.addView(infoRow("Boyut", sizeStr, cardBg, textColor, mutedColor, borderColor))
        }

        // === AKSİYONLAR ===
        root.addView(section("⚡ AKSİYONLAR", mutedColor))

        val hasShizuku = ShizukuHelper.isAvailable() && ShizukuHelper.hasPermission()

        root.addView(TextView(this).apply {
            text = if (hasShizuku) "✓ Shizuku AKTİF" else "⚠ Shizuku izni yok"
            textSize = 13f
            setTextColor(Color.parseColor(if (hasShizuku) "#10B981" else "#F59E0B"))
            gravity = Gravity.CENTER
            setPadding(30, 15, 30, 15)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(cardBg))
                cornerRadius = 20f
                setStroke(2, Color.parseColor(if (hasShizuku) "#10B981" else "#F59E0B"))
            }
        })

        root.addView(button("🚀 Uygulamayı Aç", "#3B82F6", textColor) {
            if (!hasShizuku) { toast("Shizuku izni gerekli"); return@button }
            if (ShizukuHelper.launchApp(pkg)) toast("Açılıyor...")
            else toast("Launcher activity yok")
        })

        root.addView(button("📋 Paket Adını Kopyala", "#8B5CF6", textColor) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("pkg", pkg))
            toast("✓ Kopyalandı: $pkg")
        })

        if (hasShizuku) {
            root.addView(button("⛔ Zorla Durdur", "#F59E0B", textColor) {
                if (ShizukuHelper.forceStop(pkg)) toast("✓ Durduruldu")
                else toast("✗ Başarısız")
            })

            // DONDUR / ÇÖZ
            val frozen = ShizukuHelper.isFrozen(pkg)
            if (frozen) {
                root.addView(button("☀️ Çöz (Aktifleştir)", "#10B981", textColor) {
                    if (ShizukuHelper.unfreeze(pkg)) {
                        toast("✓ Aktifleştirildi")
                        prefs.totalFrozen = (prefs.totalFrozen - 1).coerceAtLeast(0)
                        buildUI()
                    } else toast("✗ Başarısız")
                })
            } else {
                root.addView(button("❄️ Dondur", "#60A5FA", textColor) {
                    confirmDelete(risk, "dondur") {
                        val (code, msg) = ShizukuHelper.freeze(pkg)
                        toast(msg)
                        if (code != "failed") {
                            prefs.totalFrozen = prefs.totalFrozen + 1
                            buildUI()
                        }
                    }
                })
            }

            root.addView(button("🧹 Veri Temizle", "#06B6D4", textColor) {
                confirmDelete(risk, "verileri temizle") {
                    if (ShizukuHelper.clearData(pkg)) toast("✓ Temizlendi")
                    else toast("✗ Başarısız")
                }
            })

            root.addView(button("🗑️ TAMAMEN SİL", "#DC2626", textColor) {
                confirmDelete(risk, "SİL") {
                    val (code, msg) = ShizukuHelper.forceRemove(pkg)
                    toast(msg)
                    if (code == "uninstalled" || code == "hidden" || code == "disabled") {
                        prefs.totalRemoved = prefs.totalRemoved + 1
                        finish()
                    }
                }
            })

            // === İZİNLER ===
            detail?.let {
                if (it.permissions.isNotEmpty()) {
                    root.addView(section("🔐 İZİNLER (${it.permissions.size})", mutedColor))
                    it.permissions.take(30).forEach { perm ->
                        root.addView(TextView(this).apply {
                            text = "• ${perm.removePrefix("android.permission.")}"
                            textSize = 11f
                            setTextColor(Color.parseColor(mutedColor))
                            setPadding(20, 6, 20, 6)
                        })
                    }
                    if (it.permissions.size > 30) {
                        root.addView(TextView(this).apply {
                            text = "… +${it.permissions.size - 30} tane daha"
                            textSize = 11f
                            setTextColor(Color.parseColor(mutedColor))
                            setPadding(20, 6, 20, 6)
                        })
                    }
                }
            }

            // === AKTİVİTELER ===
            val activities = ShizukuHelper.getAllActivities(pkg)
            if (activities.isNotEmpty()) {
                root.addView(section("🎯 ACTIVITY'LER (${activities.size})", mutedColor))
                activities.take(15).forEach { act ->
                    root.addView(TextView(this).apply {
                        text = act
                        textSize = 11f
                        setTextColor(Color.parseColor("#67E8F9"))
                        typeface = Typeface.MONOSPACE
                        setPadding(20, 12, 20, 12)
                        background = GradientDrawable().apply {
                            setColor(Color.parseColor(cardBg))
                            cornerRadius = 15f
                            setStroke(1, Color.parseColor(borderColor))
                        }
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { setMargins(0, 5, 0, 5) }
                        isClickable = true
                        setOnClickListener {
                            if (ShizukuHelper.launchActivity(act)) toast("✓ Başlatıldı")
                            else toast("✗ Başarısız")
                        }
                    })
                }
            }
        }

        setContentView(scroll)
    }

    // ============================================
    // DETAYLI UYARI (kritik için 2 aşamalı)
    // ============================================
    private fun confirmDelete(risk: CriticalApps.RiskLevel, action: String, onYes: () -> Unit) {
        when (risk.level) {
            "critical" -> {
                AlertDialog.Builder(this)
                    .setTitle("🚨 ÇOK TEHLİKELİ!")
                    .setMessage(
                        "Bu uygulama cihaz için KRİTİK!\n\n" +
                        "📦 Paket: $pkg\n\n" +
                        "⚠️ Neden kritik:\n" +
                        "${risk.reason}\n\n" +
                        "❗ Ne olabilir:\n" +
                        "• Telefon açılmaz (bootloop)\n" +
                        "• Ayarlar çalışmaz\n" +
                        "• Arama yapılamaz\n" +
                        "• Sistem bozulabilir\n\n" +
                        "🔄 Geri almak için fabrika ayarlarına dönmen gerekir.\n\n" +
                        "YİNE DE ${action.uppercase()} İSTİYOR MUSUN?"
                    )
                    .setPositiveButton("⚠️ RİSKİ KABUL EDİYORUM") { _, _ ->
                        AlertDialog.Builder(this)
                            .setTitle("⚠️ SON UYARI")
                            .setMessage(
                                "GERÇEKTEN EMİN MİSİN?\n\n" +
                                "Cihazın açılmayabilir.\n" +
                                "Tüm verilerini kaybedebilirsin.\n" +
                                "Bu işlem geri alınamaz.\n\n" +
                                "Son karar:"
                            )
                            .setPositiveButton("🔥 EVET, YAP") { _, _ -> onYes() }
                            .setNegativeButton("VAZGEÇ", null)
                            .show()
                    }
                    .setNegativeButton("HAYIR, İPTAL", null)
                    .show()
            }
            "warning" -> {
                AlertDialog.Builder(this)
                    .setTitle("⚠️ Dikkat")
                    .setMessage(
                        "${risk.message}\n\n" +
                        "${risk.reason}\n\n" +
                        "📦 $pkg\n\n" +
                        "Bu uygulamayı $action istiyor musun?"
                    )
                    .setPositiveButton("Devam Et") { _, _ -> onYes() }
                    .setNegativeButton("Vazgeç", null)
                    .show()
            }
            else -> {
                AlertDialog.Builder(this)
                    .setTitle("Onayla")
                    .setMessage("Bu uygulamayı $action istediğine emin misin?\n\n$pkg")
                    .setPositiveButton("Evet") { _, _ -> onYes() }
                    .setNegativeButton("İptal", null)
                    .show()
            }
        }
    }

    // ============================================
    // YARDIMCI UI
    // ============================================
    private fun section(t: String, mutedColor: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#A78BFA"))
        typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setPadding(0, 40, 0, 15)
    }

    private fun infoRow(label: String, value: String, cardBg: String,
                        textColor: String, mutedColor: String, borderColor: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(25, 18, 25, 18)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(cardBg))
                cornerRadius = 15f
                setStroke(1, Color.parseColor(borderColor))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 4, 0, 4) }

            addView(TextView(this@AppDetailActivity).apply {
                text = label
                textSize = 13f
                setTextColor(Color.parseColor(mutedColor))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            addView(TextView(this@AppDetailActivity).apply {
                text = value
                textSize = 13f
                setTextColor(Color.parseColor(textColor))
                typeface = Typeface.create("sans-serif", Typeface.BOLD)
            })
        }
    }

    private fun button(label: String, color: String, textColor: String, action: () -> Unit): TextView =
        TextView(this).apply {
            this.text = label
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(40, 38, 40, 38)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(color))
                cornerRadius = 30f
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 8, 0, 8) }
            isClickable = true
            setOnClickListener { v ->
                if (prefs.animationsOn) {
                    val scale = ScaleAnimation(1f, 0.95f, 1f, 0.95f,
                        android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f,
                        android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f).apply {
                        duration = 100
                        repeatCount = 1
                        repeatMode = android.view.animation.Animation.REVERSE
                    }
                    v.startAnimation(scale)
                }
                action()
            }
        }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}