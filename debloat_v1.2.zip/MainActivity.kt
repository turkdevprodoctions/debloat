package com.centerteam.shell

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var listContainer: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var statusText: TextView
    private lateinit var statsText: TextView
    private lateinit var selectAllBtn: TextView
    private lateinit var deleteSelectedBtn: TextView
    private lateinit var root: LinearLayout

    private var allPackages: List<PackageItem> = emptyList()
    private var filtered: List<PackageItem> = emptyList()

    private var filterMode = "all"
    private var selectionMode = false
    private val selectedPkgs = mutableSetOf<String>()
    private var isLoading = false

    data class PackageItem(
        val pkg: String,
        val name: String,
        val icon: Drawable?,
        val isSystem: Boolean,
        val isEnabled: Boolean,
        val isFrozen: Boolean,
        val isFavorite: Boolean
    )

    private val shizukuListener =
        Shizuku.OnRequestPermissionResultListener { code, result ->
            if (code == ShizukuHelper.PERMISSION_REQUEST_CODE) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    toast("✓ Shizuku izni verildi")
                    loadAll()
                } else {
                    toast("✗ Reddedildi")
                }
                updateStatus()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)

        // İlk açılış → setup ekranı
        if (!prefs.setupCompleted && !ShizukuHelper.hasPermission()) {
            startActivity(Intent(this, ShizukuSetupActivity::class.java))
        }

        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (_: Exception) {}

        filterMode = prefs.lastFilter
        buildUI()
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (ShizukuHelper.hasPermission() && !isLoading) loadAll()
    }

    // ============================================
    // ANA UI
    // ============================================
    private fun buildUI() {
        val dark = prefs.isDark()
        val bg = if (dark) "#0B1120" else "#F8FAFC"
        val bg2 = if (dark) "#1E1B4B" else "#EEF2FF"
        val cardBg = if (dark) "#1E293B" else "#FFFFFF"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"
        val borderColor = if (dark) "#334155" else "#E2E8F0"

        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor(bg), Color.parseColor(bg2))
            )
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 80, 24, 80)
        }
        scroll.addView(root)

        // === HEADER ===
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 20)
        }

        // Logo kutusu
        val logoBox = TextView(this).apply {
            text = "D"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899"))
            ).apply { cornerRadius = 20f }
            layoutParams = LinearLayout.LayoutParams(80, 80)
        }
        header.addView(logoBox)

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleCol.addView(TextView(this).apply {
            text = "Debloat"
            textSize = 24f
            setTextColor(Color.parseColor(textColor))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        titleCol.addView(TextView(this).apply {
            text = "v1.2.0"
            textSize = 11f
            setTextColor(Color.parseColor(mutedColor))
        })
        header.addView(titleCol)

        // Tema butonu
        header.addView(TextView(this).apply {
            text = if (dark) "☀️" else "🌙"
            textSize = 22f
            setPadding(15, 10, 15, 10)
            isClickable = true
            setOnClickListener {
                prefs.theme = when (prefs.theme) {
                    "dark" -> "light"
                    "light" -> "auto"
                    else -> "dark"
                }
                toast("Tema: ${when (prefs.theme) {
                    "dark" -> "Koyu"
                    "light" -> "Açık"
                    else -> "Otomatik"
                }}")
                recreate()
            }
        })

        // Ayarlar butonu
        header.addView(TextView(this).apply {
            text = "⚙️"
            textSize = 22f
            setPadding(15, 10, 15, 10)
            isClickable = true
            setOnClickListener { showSettings() }
        })
        root.addView(header)

        // === STATS CARD ===
        statsText = TextView(this).apply {
            text = "📊 ${prefs.totalRemoved} silindi  •  ❄ ${prefs.totalFrozen} donduruldu"
            textSize = 13f
            setTextColor(Color.parseColor("#A78BFA"))
            gravity = Gravity.CENTER
            setPadding(20, 15, 20, 15)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(cardBg))
                cornerRadius = 20f
                setStroke(2, Color.parseColor("#8B5CF6"))
            }
        }
        root.addView(statsText)

        // === DURUM ===
        statusText = TextView(this).apply {
            text = "Kontrol ediliyor..."
            textSize = 13f
            setTextColor(Color.parseColor(textColor))
            setPadding(25, 18, 25, 18)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(cardBg))
                cornerRadius = 20f
                setStroke(1, Color.parseColor(borderColor))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 15, 0, 0) }
        }
        root.addView(statusText)

        // === İZİN BUTONU ===
        root.addView(primaryButton("🔓 Shizuku İzni Al", "#3B82F6") {
            if (!ShizukuHelper.isAvailable()) {
                toast("Shizuku çalışmıyor")
                startActivity(Intent(this, ShizukuSetupActivity::class.java))
                return@primaryButton
            }
            if (ShizukuHelper.hasPermission()) {
                toast("Zaten izinli")
                return@primaryButton
            }
            ShizukuHelper.requestPermission()
        })

        // === ARAMA ===
        searchInput = EditText(this).apply {
            hint = "⌕ Uygulama ara..."
            setTextColor(Color.parseColor(textColor))
            setHintTextColor(Color.parseColor(mutedColor))
            textSize = 15f
            setBackgroundColor(Color.parseColor(cardBg))
            setPadding(40, 30, 40, 30)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 15, 0, 15) }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                    applySearch(s?.toString() ?: "")
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(searchInput)

        // === FİLTRELER ===
        val filterRow1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 8)
        }
        filterRow1.addView(filterChip("Tümü", "all"))
        filterRow1.addView(filterChip("⚙️ Sistem", "system"))
        filterRow1.addView(filterChip("📱 Kullanıcı", "user"))
        filterRow1.addView(filterChip("⭐ Favori", "favorites"))
        root.addView(filterRow1)

        val filterRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 15)
        }
        filterRow2.addView(filterChip("🔍 Google", "google"))
        filterRow2.addView(filterChip("📦 Samsung", "samsung"))
        filterRow2.addView(filterChip("❄️ Dondurulmuş", "frozen"))
        root.addView(filterRow2)

        // === SEÇİM BUTONLARI ===
        val selectRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 15)
        }

        selectAllBtn = TextView(this).apply {
            text = "☐ Toplu Seç"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(20, 22, 20, 22)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F59E0B"))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(0, 0, 8, 0) }
            isClickable = true
            setOnClickListener { toggleSelectionMode() }
        }
        selectRow.addView(selectAllBtn)

        deleteSelectedBtn = TextView(this).apply {
            text = "🗑 Sil (0)"
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(20, 22, 20, 22)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#DC2626"))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(8, 0, 0, 0) }
            isClickable = true
            visibility = if (selectionMode) View.VISIBLE else View.GONE
            setOnClickListener { deleteSelected() }
        }
        selectRow.addView(deleteSelectedBtn)
        root.addView(selectRow)

        // === LİSTE ===
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        root.addView(listContainer)

        setContentView(scroll)
    }

    // ============================================
    // DURUM
    // ============================================
    private fun updateStatus() {
        if (!this::statusText.isInitialized) return
        when {
            !ShizukuHelper.isAvailable() -> {
                statusText.text = "❌ Shizuku kurulu değil"
                statusText.setTextColor(Color.parseColor("#EF4444"))
            }
            !ShizukuHelper.hasPermission() -> {
                statusText.text = "⚠ Shizuku hazır, izin lazım"
                statusText.setTextColor(Color.parseColor("#F59E0B"))
            }
            else -> {
                statusText.text = "✓ Shizuku hazır"
                statusText.setTextColor(Color.parseColor("#10B981"))
                if (!isLoading) loadAll()
            }
        }
    }

    // ============================================
    // YÜKLEME (donma düzeltmesi: arka planda)
    // ============================================
    private fun loadAll() {
        if (!ShizukuHelper.hasPermission()) return
        if (isLoading) return
        isLoading = true

        Handler(Looper.getMainLooper()).post {
            try {
                val pm = packageManager
                val packages = pm.getInstalledPackages(
                    PackageManager.MATCH_DISABLED_COMPONENTS or
                            PackageManager.MATCH_UNINSTALLED_PACKAGES
                )
                val favs = prefs.getFavorites()
                val frozenList = try {
                    ShizukuHelper.exec(arrayOf("pm", "list", "packages", "-d", "-u"))
                        .lines().map { it.removePrefix("package:").trim() }.toSet()
                } catch (e: Exception) { emptySet<String>() }

                allPackages = packages.mapNotNull { info ->
                    try {
                        val app: ApplicationInfo = info.applicationInfo ?: return@mapNotNull null
                        val isSys = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                                (app.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
                        PackageItem(
                            pkg = info.packageName,
                            name = pm.getApplicationLabel(app).toString(),
                            icon = try { pm.getApplicationIcon(app) } catch (e: Exception) { null },
                            isSystem = isSys,
                            isEnabled = app.enabled,
                            isFrozen = frozenList.contains(info.packageName),
                            isFavorite = favs.contains(info.packageName)
                        )
                    } catch (e: Exception) { null }
                }.distinctBy { it.pkg }.sortedWith(
                    compareByDescending<PackageItem> { it.isFavorite }
                        .thenBy { it.name.lowercase() }
                )

                applyFilterAndRender()
            } catch (e: Exception) {
                toast("Yükleme hatası: ${e.message}")
            }
            isLoading = false
        }
    }

    private fun applyFilterAndRender() {
        filtered = when (filterMode) {
            "system" -> allPackages.filter { it.isSystem }
            "user" -> allPackages.filter { !it.isSystem }
            "frozen" -> allPackages.filter { it.isFrozen }
            "favorites" -> allPackages.filter { it.isFavorite }
            "google" -> allPackages.filter {
                it.pkg.startsWith("com.google.") || it.pkg.startsWith("com.android.vending")
            }
            "samsung" -> allPackages.filter {
                it.pkg.startsWith("com.samsung.") || it.pkg.startsWith("com.sec.")
            }
            else -> allPackages
        }
        renderList()
    }

    private fun applySearch(q: String) {
        if (q.isBlank()) {
            applyFilterAndRender()
        } else {
            val base = when (filterMode) {
                "system" -> allPackages.filter { it.isSystem }
                "user" -> allPackages.filter { !it.isSystem }
                "frozen" -> allPackages.filter { it.isFrozen }
                "favorites" -> allPackages.filter { it.isFavorite }
                "google" -> allPackages.filter {
                    it.pkg.startsWith("com.google.") || it.pkg.startsWith("com.android.vending")
                }
                "samsung" -> allPackages.filter {
                    it.pkg.startsWith("com.samsung.") || it.pkg.startsWith("com.sec.")
                }
                else -> allPackages
            }
            filtered = base.filter {
                it.pkg.contains(q, true) || it.name.contains(q, true)
            }
            renderList()
        }
    }

    // ============================================
    // LİSTE ÇİZİM + ANİMASYON
    // ============================================
    private fun renderList() {
        if (!this::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val dark = prefs.isDark()
        val cardBg = if (dark) "#1E293B" else "#FFFFFF"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"
        val borderColor = if (dark) "#334155" else "#E2E8F0"

        if (filtered.isEmpty()) {
            listContainer.addView(TextView(this).apply {
                text = "🔍 Paket bulunamadı"
                textSize = 14f
                setTextColor(Color.parseColor(mutedColor))
                gravity = Gravity.CENTER
                setPadding(0, 60, 0, 60)
            })
            return
        }

        listContainer.addView(TextView(this).apply {
            text = "${filtered.size} paket"
            textSize = 12f
            setTextColor(Color.parseColor(mutedColor))
            setPadding(0, 0, 0, 15)
        })

        filtered.take(200).forEachIndexed { index, item ->
            val risk = CriticalApps.check(item.pkg)
            val rowColor = when {
                risk.level == "critical" -> if (dark) "#4A1010" else "#FEE2E2"
                risk.level == "warning" -> if (dark) "#4A3A10" else "#FEF3C7"
                risk.level == "safe" -> if (dark) "#103A1F" else "#D1FAE5"
                else -> cardBg
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(20, 18, 20, 18)
                background = GradientDrawable().apply {
                    setColor(Color.parseColor(rowColor))
                    cornerRadius = 20f
                    if (selectionMode && selectedPkgs.contains(item.pkg)) {
                        setStroke(3, Color.parseColor("#8B5CF6"))
                    } else {
                        setStroke(1, Color.parseColor(borderColor))
                    }
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(0, 5, 0, 5) }
                isClickable = true
                setOnClickListener {
                    if (selectionMode) toggleSelect(item.pkg)
                    else openDetail(item.pkg)
                }
                setOnLongClickListener {
                    if (!selectionMode) {
                        selectionMode = true
                        selectedPkgs.add(item.pkg)
                        selectAllBtn.text = "✕ İptal"
                        deleteSelectedBtn.visibility = View.VISIBLE
                        deleteSelectedBtn.text = "🗑 Sil (1)"
                        renderList()
                    }
                    true
                }
            }

            // Checkbox
            if (selectionMode) {
                card.addView(CheckBox(this).apply {
                    isChecked = selectedPkgs.contains(item.pkg)
                    isClickable = false
                    buttonTintList = android.content.res.ColorStateList.valueOf(
                        Color.parseColor("#8B5CF6")
                    )
                    layoutParams = LinearLayout.LayoutParams(60, 60)
                })
            }

            // İkon
            card.addView(ImageView(this).apply {
                setImageDrawable(item.icon)
                layoutParams = LinearLayout.LayoutParams(90, 90).apply {
                    setMargins(0, 0, 20, 0)
                }
                scaleType = ImageView.ScaleType.FIT_CENTER
            })

            // Metinler
            val texts = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }

            val prefix = when {
                risk.level == "critical" -> "🚨 "
                risk.level == "warning" -> "⚠️ "
                risk.level == "safe" -> "✓ "
                else -> ""
            }
            val favMark = if (item.isFavorite) "⭐ " else ""

            texts.addView(TextView(this).apply {
                text = prefix + favMark + item.name
                textSize = 15f
                setTextColor(Color.parseColor(textColor))
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            })
            texts.addView(TextView(this).apply {
                text = item.pkg
                textSize = 10f
                setTextColor(Color.parseColor(mutedColor))
                setPadding(0, 4, 0, 0)
            })

            if (item.isFrozen) {
                texts.addView(TextView(this).apply {
                    text = "❄ Dondurulmuş"
                    textSize = 11f
                    setTextColor(Color.parseColor("#60A5FA"))
                    setPadding(0, 4, 0, 0)
                })
            }

            card.addView(texts)

            card.addView(TextView(this).apply {
                text = "›"
                textSize = 24f
                setTextColor(Color.parseColor(mutedColor))
            })

            listContainer.addView(card)

            // Giriş animasyonu (staggered)
            if (prefs.animationsOn && index < 20) {
                card.alpha = 0f
                card.translationY = 30f
                card.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setStartDelay((index * 20).toLong())
                    .setDuration(300)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
        }
    }

    // ============================================
    // SEÇİM
    // ============================================
    private fun toggleSelectionMode() {
        selectionMode = !selectionMode
        selectedPkgs.clear()
        selectAllBtn.text = if (selectionMode) "✕ İptal" else "☐ Toplu Seç"
        deleteSelectedBtn.visibility = if (selectionMode) View.VISIBLE else View.GONE
        deleteSelectedBtn.text = "🗑 Sil (0)"
        renderList()
    }

    private fun toggleSelect(pkg: String) {
        if (selectedPkgs.contains(pkg)) selectedPkgs.remove(pkg)
        else selectedPkgs.add(pkg)
        deleteSelectedBtn.text = "🗑 Sil (${selectedPkgs.size})"
        renderList()
    }

    private fun deleteSelected() {
        if (selectedPkgs.isEmpty()) { toast("Hiçbir şey seçilmedi"); return }

        // Kritik uygulama var mı?
        val hasCritical = selectedPkgs.any {
            CriticalApps.check(it).level == "critical"
        }

        val msg = if (hasCritical) {
            "⚠️ SEÇİLENLER ARASINDA KRİTİK UYGULAMA VAR!\n\n" +
                    "${selectedPkgs.size} uygulama silinecek.\n\n" +
                    "Cihazın bozulma riski var. Devam?"
        } else {
            "${selectedPkgs.size} uygulama silinecek. Emin misin?"
        }

        AlertDialog.Builder(this)
            .setTitle("⚠️ Toplu Silme")
            .setMessage(msg)
            .setPositiveButton("Evet, Sil") { _, _ ->
                var okCount = 0
                var failCount = 0
                selectedPkgs.forEach { pkg ->
                    val (code, _) = ShizukuHelper.forceRemove(pkg)
                    if (code == "uninstalled" || code == "hidden" || code == "disabled") okCount++
                    else failCount++
                }
                prefs.totalRemoved = prefs.totalRemoved + okCount
                toast("✓ $okCount silindi, ✗ $failCount başarısız")
                selectedPkgs.clear()
                selectionMode = false
                selectAllBtn.text = "☐ Toplu Seç"
                deleteSelectedBtn.visibility = View.GONE
                statsText.text = "📊 ${prefs.totalRemoved} silindi  •  ❄ ${prefs.totalFrozen} donduruldu"
                loadAll()
            }
            .setNegativeButton("İptal", null)
            .show()
    }

    // ============================================
    // AYARLAR DİYALOĞU
    // ============================================
    private fun showSettings() {
        val dark = prefs.isDark()
        val options = arrayOf(
            "🎨 Tema: ${when (prefs.theme) {
                "dark" -> "Koyu"
                "light" -> "Açık"
                else -> "Otomatik"
            }}",
            "✨ Animasyonlar: ${if (prefs.animationsOn) "Açık" else "Kapalı"}",
            "🔄 Uygulama Listesini Yenile",
            "📊 İstatistikleri Sıfırla",
            "ℹ️ Hakkında"
        )

        AlertDialog.Builder(this)
            .setTitle("⚙️ Ayarlar")
            .setItems(options) { _, i ->
                when (i) {
                    0 -> {
                        prefs.theme = when (prefs.theme) {
                            "dark" -> "light"
                            "light" -> "auto"
                            else -> "dark"
                        }
                        recreate()
                    }
                    1 -> {
                        prefs.animationsOn = !prefs.animationsOn
                        toast("Animasyonlar: ${if (prefs.animationsOn) "Açık" else "Kapalı"}")
                    }
                    2 -> loadAll()
                    3 -> {
                        AlertDialog.Builder(this)
                            .setTitle("İstatistikleri Sıfırla?")
                            .setPositiveButton("Sıfırla") { _, _ ->
                                prefs.totalRemoved = 0
                                prefs.totalFrozen = 0
                                statsText.text = "📊 0 silindi  •  ❄ 0 donduruldu"
                                toast("Sıfırlandı")
                            }
                            .setNegativeButton("İptal", null)
                            .show()
                    }
                    4 -> showAbout()
                }
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showAbout() {
        AlertDialog.Builder(this)
            .setTitle("ℹ️ Debloat v1.2.0")
            .setMessage(
                "DevSoft Inc. tarafından geliştirildi.\n\n" +
                        "• Shizuku ile sistem uygulama yöneticisi\n" +
                        "• Root gerekmez\n" +
                        "• Reklamsız, veri toplamaz\n" +
                        "• Açık kaynak (MIT)\n\n" +
                        "📧 devsoft@outlook.com.tr\n" +
                        "🌐 center-store-silk.vercel.app"
            )
            .setPositiveButton("Tamam", null)
            .show()
    }

    // ============================================
    // DETAY AÇ
    // ============================================
    private fun openDetail(pkg: String) {
        val i = Intent(this, AppDetailActivity::class.java)
        i.putExtra("package", pkg)
        startActivity(i)
        if (prefs.animationsOn) {
            overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )
        }
    }

    // ============================================
    // YARDIMCI UI
    // ============================================
    private fun filterChip(label: String, mode: String): TextView {
        val dark = prefs.isDark()
        val active = filterMode == mode
        return TextView(this).apply {
            text = label
            textSize = 11f
            setTextColor(if (active) Color.WHITE else Color.parseColor(
                if (dark) "#94A3B8" else "#64748B"
            ))
            gravity = Gravity.CENTER
            setPadding(12, 15, 12, 15)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(
                    if (active) "#8B5CF6"
                    else if (dark) "#334155" else "#E2E8F0"
                ))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(4, 0, 4, 0) }
            isClickable = true
            setOnClickListener {
                filterMode = mode
                prefs.lastFilter = mode
                buildUI()
                if (ShizukuHelper.hasPermission()) applyFilterAndRender()
            }
        }
    }

    private fun primaryButton(label: String, color: String, action: () -> Unit): TextView {
        val btn = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(40, 38, 40, 38)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor(color), Color.parseColor("#EC4899"))
            ).apply { cornerRadius = 40f }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 12, 0, 12) }
            isClickable = true
            setOnClickListener { v ->
                if (prefs.animationsOn) {
                    val scale = ScaleAnimation(1f, 0.95f, 1f, 0.95f,
                        android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f,
                        android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f).apply {
                        duration = 100
                        repeatCount = 1
                        repeatMode = android.view.animation.Animation.REVERSE
                    }
                    v.startAnimation(scale)
                }
                action()
            }
        }
        return btn
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (_: Exception) {}
    }
}