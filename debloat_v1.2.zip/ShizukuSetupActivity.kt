package com.centerteam.shell

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.DecelerateInterpolator
import android.view.animation.ScaleAnimation
import android.view.animation.TranslateAnimation
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class ShizukuSetupActivity : Activity() {

    private lateinit var prefs: PrefsHelper
    private lateinit var stepContainer: LinearLayout
    private lateinit var contentContainer: LinearLayout
    private lateinit var progressBar: LinearLayout
    private var currentStep = 0
    private val totalSteps = 5

    private val shizukuListener =
        Shizuku.OnRequestPermissionResultListener { code, result ->
            if (code == ShizukuHelper.PERMISSION_REQUEST_CODE) {
                if (result == PackageManager.PERMISSION_GRANTED) {
                    toast("✓ Shizuku izni verildi!")
                    goToStep(4)
                } else {
                    toast("✗ İzin reddedildi, tekrar dene")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsHelper(this)
        try {
            Shizuku.addRequestPermissionResultListener(shizukuListener)
        } catch (_: Exception) {}

        buildUI()
        showStep(0)
    }

    // ============================================
    // ANA UI
    // ============================================
    private fun buildUI() {
        val dark = prefs.isDark()
        val bg = if (dark) "#0B1120" else "#F8FAFC"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"

        val scroll = ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.parseColor(bg),
                    Color.parseColor(if (dark) "#1E1B4B" else "#EEF2FF")
                )
            )
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 100, 40, 80)
        }
        scroll.addView(root)

        // === LOGO ANİMASYONU ===
        val logo = TextView(this).apply {
            text = "◉"
            textSize = 80f
            setTextColor(Color.parseColor("#8B5CF6"))
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        root.addView(logo)

        // Logo pulse animasyonu
        val pulse = ScaleAnimation(
            1f, 1.15f, 1f, 1.15f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f
        ).apply {
            duration = 800
            repeatMode = Animation.REVERSE
            repeatCount = Animation.INFINITE
            interpolator = DecelerateInterpolator()
        }
        logo.startAnimation(pulse)

        // === BAŞLIK ===
        root.addView(TextView(this).apply {
            text = "Debloat Kurulum"
            textSize = 30f
            setTextColor(Color.parseColor(textColor))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, 30, 0, 10)
        })

        root.addView(TextView(this).apply {
            text = "Shizuku ile sistem uygulamalarını yönet"
            textSize = 14f
            setTextColor(Color.parseColor(if (dark) "#94A3B8" else "#64748B"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 40)
        })

        // === PROGRESS BAR ===
        progressBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, 40)
            gravity = Gravity.CENTER
        }
        root.addView(progressBar)

        // === ADIM GÖSTERGESİ ===
        stepContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 30)
        }
        root.addView(stepContainer)

        // === İÇERİK ===
        contentContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }
        root.addView(contentContainer)

        setContentView(scroll)
    }

    // ============================================
    // ADIMI GÖSTER
    // ============================================
    private fun showStep(step: Int) {
        currentStep = step

        // Progress bar güncelle
        updateProgressBar()

        // İçeriği temizle
        contentContainer.removeAllViews()

        // Adım içeriği
        when (step) {
            0 -> step0Welcome()
            1 -> step1InstallShizuku()
            2 -> step2EnableDebug()
            3 -> step3StartShizuku()
            4 -> step4GrantPermission()
            5 -> step5Complete()
        }

        // Giriş animasyonu
        if (prefs.animationsOn) {
            val fadeIn = AlphaAnimation(0f, 1f).apply { duration = 400 }
            val slide = TranslateAnimation(0f, 0f, 60f, 0f).apply { duration = 400 }
            contentContainer.startAnimation(fadeIn)
            contentContainer.startAnimation(slide)
        }
    }

    private fun goToStep(step: Int) {
        if (prefs.animationsOn) {
            val fadeOut = AlphaAnimation(1f, 0f).apply { duration = 250 }
            fadeOut.setAnimationListener(object : Animation.AnimationListener {
                override fun onAnimationStart(a: Animation?) {}
                override fun onAnimationEnd(a: Animation?) { showStep(step) }
                override fun onAnimationRepeat(a: Animation?) {}
            })
            contentContainer.startAnimation(fadeOut)
        } else {
            showStep(step)
        }
    }

    // ============================================
    // PROGRESS BAR
    // ============================================
    private fun updateProgressBar() {
        progressBar.removeAllViews()
        val dark = prefs.isDark()
        for (i in 0 until totalSteps) {
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor(
                        if (i <= currentStep) "#8B5CF6"
                        else if (dark) "#334155" else "#E2E8F0"
                    ))
                }
                layoutParams = LinearLayout.LayoutParams(
                    if (i == currentStep) 40 else 16,
                    16
                ).apply { setMargins(6, 0, 6, 0) }
            }
            progressBar.addView(dot)
        }
    }

    // ============================================
    // ADIM 0: HOŞ GELDİN
    // ============================================
    private fun step0Welcome() {
        val dark = prefs.isDark()
        val cardBg = if (dark) "#1E293B" else "#FFFFFF"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        addIcon("👋", "#8B5CF6")
        addTitle("Debloat'a Hoş Geldin!", textColor)
        addText("Kurulum sadece 5 adım sürecek. Shizuku ile sistem uygulamalarını güvenle yönetebileceksin.", mutedColor)

        // Bilgi kartları
        addInfoCard("⚡", "Hızlı Kurulum", "5 adımda hazır", "#10B981", cardBg, textColor, mutedColor)
        addInfoCard("🔒", "Güvenli", "Root gerekmez", "#3B82F6", cardBg, textColor, mutedColor)
        addInfoCard("🚀", "Güçlü", "Tüm sistem uygulamalarını yönet", "#EC4899", cardBg, textColor, mutedColor)

        addSpacer(30)
        addPrimaryButton("Başlayalım →", "#8B5CF6") {
            goToStep(1)
        }
    }

    // ============================================
    // ADIM 1: SHIZUKU KUR
    // ============================================
    private fun step1InstallShizuku() {
        val dark = prefs.isDark()
        val cardBg = if (dark) "#1E293B" else "#FFFFFF"
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        addStepBadge("1 / 5", "#8B5CF6")
        addIcon("📥", "#3B82F6")
        addTitle("Shizuku'yu Kur", textColor)
        addText("Shizuku, root olmadan sistem uygulamalarını yönetmek için gerekli. Play Store'dan ücretsiz indir.", mutedColor)

        addSpacer(20)
        addSecondaryButton("🛒 Play Store'da Aç", "#10B981") {
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api")
                }
                startActivity(intent)
            } catch (e: Exception) {
                toast("Play Store açılamadı")
            }
        }

        addSpacer(20)
        addText("Shizuku'yu kurduktan sonra ilerle.", mutedColor)

        addSpacer(30)
        addNavButtons(
            back = { goToStep(0) },
            next = { goToStep(2) }
        )
    }

    // ============================================
    // ADIM 2: KABLOSUZ HATA AYIKLAMA
    // ============================================
    private fun step2EnableDebug() {
        val dark = prefs.isDark()
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        addStepBadge("2 / 5", "#3B82F6")
        addIcon("⚙️", "#F59E0B")
        addTitle("Kablosuz Hata Ayıklama", textColor)
        addText("Shizuku'nun çalışması için geliştirici seçeneklerinden kablosuz hata ayıklamayı açman gerek.", mutedColor)

        addSpacer(20)
        addNumberedStep("1", "Ayarlar → Telefon Hakkında'ya git", textColor, mutedColor)
        addNumberedStep("2", "Build Numarası'na 7 kere bas", textColor, mutedColor)
        addNumberedStep("3", "Geliştirici Seçenekleri açılır", textColor, mutedColor)
        addNumberedStep("4", "Kablosuz Hata Ayıklama'yı AÇ", textColor, mutedColor)

        addSpacer(20)
        addSecondaryButton("⚙️ Geliştirici Seçeneklerini Aç", "#F59E0B") {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            } catch (e: Exception) {
                toast("Ayarlar açılamadı")
            }
        }

        addSpacer(30)
        addNavButtons(
            back = { goToStep(1) },
            next = { goToStep(3) }
        )
    }

    // ============================================
    // ADIM 3: SHIZUKU'YU BAŞLAT
    // ============================================
    private fun step3StartShizuku() {
        val dark = prefs.isDark()
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        addStepBadge("3 / 5", "#F59E0B")
        addIcon("🚀", "#EC4899")
        addTitle("Shizuku'yu Başlat", textColor)
        addText("Shizuku uygulamasını aç ve servisi başlat.", mutedColor)

        addSpacer(20)
        addNumberedStep("1", "Shizuku uygulamasını aç", textColor, mutedColor)
        addNumberedStep("2", "Pairing (Eşleştirme) yap", textColor, mutedColor)
        addNumberedStep("3", "\"Start\" butonuna bas", textColor, mutedColor)
        addNumberedStep("4", "Servis başlayana kadar bekle", textColor, mutedColor)

        addSpacer(20)

        // Durum kontrolü
        val statusCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 25, 30, 25)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(
                    if (ShizukuHelper.isAvailable()) "#10B981" else "#F59E0B"
                ))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 20) }
        }
        statusCard.addView(TextView(this).apply {
            text = if (ShizukuHelper.isAvailable()) "✓ Shizuku ÇALIŞIYOR" else "⏳ Shizuku bekleniyor..."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        contentContainer.addView(statusCard)

        addSecondaryButton("🔄 Durumu Kontrol Et", "#06B6D4") {
            if (ShizukuHelper.isAvailable()) {
                toast("✓ Shizuku aktif!")
                goToStep(4)
            } else {
                toast("Shizuku henüz başlamadı")
            }
            showStep(3)
        }

        addSpacer(30)
        addNavButtons(
            back = { goToStep(2) },
            next = {
                if (ShizukuHelper.isAvailable()) goToStep(4)
                else toast("Önce Shizuku'yu başlat")
            }
        )
    }

    // ============================================
    // ADIM 4: İZİN VER
    // ============================================
    private fun step4GrantPermission() {
        val dark = prefs.isDark()
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        addStepBadge("4 / 5", "#EC4899")
        addIcon("🔓", "#10B981")
        addTitle("İzin Ver", textColor)
        addText("Debloat'a Shizuku üzerinden sistem yetkisi vermen gerekiyor.", mutedColor)

        addSpacer(20)

        if (ShizukuHelper.hasPermission()) {
            addStatusCard("✓ İzin zaten verildi!", "#10B981")
            addSpacer(20)
            addPrimaryButton("Devam →", "#10B981") { goToStep(5) }
        } else {
            addText("Aşağıdaki butona bas ve açılan pencerede \"İzin Ver\" seçeneğini seç.", mutedColor)
            addSpacer(20)
            addPrimaryButton("🔓 İzin İste", "#10B981") {
                if (!ShizukuHelper.isAvailable()) {
                    toast("Shizuku çalışmıyor")
                    return@addPrimaryButton
                }
                ShizukuHelper.requestPermission()
            }
        }

        addSpacer(30)
        addNavButtons(
            back = { goToStep(3) },
            next = {
                if (ShizukuHelper.hasPermission()) goToStep(5)
                else toast("Önce izin ver")
            }
        )
    }

    // ============================================
    // ADIM 5: TAMAMLANDI
    // ============================================
    private fun step5Complete() {
        val dark = prefs.isDark()
        val textColor = if (dark) "#FFFFFF" else "#0F172A"
        val mutedColor = if (dark) "#94A3B8" else "#64748B"

        // Kutlama animasyonu
        addIcon("🎉", "#10B981")
        addTitle("Hazırsın!", textColor)
        addText("Debloat artık kullanıma hazır. Sistem uygulamalarını güvenle yönetebilirsin.", mutedColor)

        addSpacer(30)

        // Başarı kartı
        addStatusCard("✓ Kurulum tamamlandı!", "#10B981")

        addSpacer(20)
        addText("İpuçları:", textColor)
        addNumberedStep("💡", "Uzun bas → toplu seçim", textColor, mutedColor)
        addNumberedStep("⭐", "Favori eklemek için yıldıza bas", textColor, mutedColor)
        addNumberedStep("❄️", "Silmeden dondur, sonra çöz", textColor, mutedColor)
        addNumberedStep("⚠️", "Kritik uygulamalarda çift onay var", textColor, mutedColor)

        addSpacer(30)
        addPrimaryButton("🚀 Debloat'ı Aç", "#10B981") {
            prefs.setupCompleted = true
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            finish()
        }

        addSpacer(15)
        addSecondaryButton("Tekrar Kur", "#64748B") {
            goToStep(0)
        }
    }

    // ============================================
    // YARDIMCI UI BİLEŞENLERİ
    // ============================================
    private fun addIcon(emoji: String, color: String) {
        val icon = TextView(this).apply {
            text = emoji
            textSize = 64f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 20) }
        }
        contentContainer.addView(icon)

        if (prefs.animationsOn) {
            val scale = ScaleAnimation(
                0.5f, 1f, 0.5f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            ).apply {
                duration = 500
                interpolator = DecelerateInterpolator()
            }
            icon.startAnimation(scale)
        }
    }

    private fun addStepBadge(text: String, color: String) {
        val badge = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(25, 10, 25, 10)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(color))
                cornerRadius = 30f
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                setMargins(0, 0, 0, 20)
            }
        }
        contentContainer.addView(badge)
    }

    private fun addTitle(text: String, color: String) {
        contentContainer.addView(TextView(this).apply {
            this.text = text
            textSize = 26f
            setTextColor(Color.parseColor(color))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, 0, 0, 15)
        })
    }

    private fun addText(text: String, color: String) {
        contentContainer.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor(color))
            gravity = Gravity.CENTER
            setPadding(20, 0, 20, 20)
            setLineSpacing(4f, 1.2f)
        })
    }

    private fun addSpacer(dp: Int) {
        contentContainer.addView(View(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp
            )
        })
    }

    private fun addInfoCard(icon: String, title: String, desc: String,
                            color: String, cardBg: String, textColor: String, mutedColor: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(25, 20, 25, 20)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(cardBg))
                cornerRadius = 20f
                setStroke(2, Color.parseColor(color))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 6, 0, 6) }
        }

        card.addView(TextView(this).apply {
            text = icon
            textSize = 28f
            setPadding(0, 0, 20, 0)
        })

        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.parseColor(textColor))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        })
        texts.addView(TextView(this).apply {
            text = desc
            textSize = 12f
            setTextColor(Color.parseColor(mutedColor))
            setPadding(0, 4, 0, 0)
        })
        card.addView(texts)

        contentContainer.addView(card)
    }

    private fun addNumberedStep(num: String, text: String, textColor: String, mutedColor: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 10, 10, 10)
        }

        row.addView(TextView(this).apply {
            this.text = num
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#8B5CF6"))
            }
            layoutParams = LinearLayout.LayoutParams(50, 50).apply {
                setMargins(0, 0, 20, 0)
            }
        })

        row.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor(textColor))
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            )
        })

        contentContainer.addView(row)
    }

    private fun addStatusCard(text: String, color: String) {
        contentContainer.addView(TextView(this).apply {
            this.text = text
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(30, 25, 30, 25)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(color))
                cornerRadius = 20f
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 10, 0, 10) }
        })
    }

    private fun addPrimaryButton(text: String, color: String, action: () -> Unit) {
        val btn = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(40, 40, 40, 40)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor(color), Color.parseColor("#EC4899"))
            ).apply { cornerRadius = 30f }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 10, 0, 10) }
            isClickable = true
            setOnClickListener {
                if (prefs.animationsOn) {
                    val scale = ScaleAnimation(1f, 0.95f, 1f, 0.95f,
                        Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f).apply {
                        duration = 100
                        repeatCount = 1
                        repeatMode = Animation.REVERSE
                    }
                    it.startAnimation(scale)
                }
                action()
            }
        }
        contentContainer.addView(btn)
    }

    private fun addSecondaryButton(text: String, color: String, action: () -> Unit) {
        val btn = TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.parseColor(color))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(30, 30, 30, 30)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#00000000"))
                cornerRadius = 30f
                setStroke(2, Color.parseColor(color))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 8, 0, 8) }
            isClickable = true
            setOnClickListener {
                if (prefs.animationsOn) {
                    val scale = ScaleAnimation(1f, 0.95f, 1f, 0.95f,
                        Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f).apply {
                        duration = 100
                        repeatCount = 1
                        repeatMode = Animation.REVERSE
                    }
                    it.startAnimation(scale)
                }
                action()
            }
        }
        contentContainer.addView(btn)
    }

    private fun addNavButtons(back: () -> Unit, next: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 10, 0, 10)
        }

        row.addView(TextView(this).apply {
            text = "← Geri"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#334155"))
                cornerRadius = 30f
            }
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { setMargins(0, 0, 8, 0) }
            isClickable = true
            setOnClickListener { back() }
        })

        row.addView(TextView(this).apply {
            text = "İleri →"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(30, 30, 30, 30)
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899"))
            ).apply { cornerRadius = 30f }
            layoutParams = LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
            ).apply { setMargins(8, 0, 0, 0) }
            isClickable = true
            setOnClickListener { next() }
        })

        contentContainer.addView(row)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuListener)
        } catch (_: Exception) {}
    }
}